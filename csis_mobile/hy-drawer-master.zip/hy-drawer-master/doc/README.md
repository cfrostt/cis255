# Documentation

* [Options](options.md)
* [Methods](methods.md)
* [Events](events.md)
* [Styling](styling.md)
